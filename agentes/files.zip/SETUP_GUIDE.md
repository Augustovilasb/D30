# 🚀 D30 BACKEND - GUIA DE SETUP COMPLETO

**Data:** 19 de maio de 2026
**Stack:** Spring Boot 3.2 + PostgreSQL + JWT + Docker

---

## 📋 PRÉ-REQUISITOS

### Instalar (se não tiver):

1. **Java JDK 17+**
   ```powershell
   java -version
   # Se não tiver: https://adoptium.net/
   ```

2. **Maven 3.9+**
   ```powershell
   mvn -version
   # Se não tiver: https://maven.apache.org/download.cgi
   ```

3. **Docker + Docker Compose**
   ```powershell
   docker --version
   docker-compose --version
   # Se não tiver: https://www.docker.com/products/docker-desktop
   ```

4. **Git** (já deve ter)
   ```powershell
   git --version
   ```

---

## 🏗️ ESTRUTURA DO PROJETO

```
d30-backend/
├── src/
│   └── main/
│       ├── java/
│       │   └── com/d30/
│       │       ├── D30Application.java
│       │       ├── controller/
│       │       │   ├── AuthController.java
│       │       │   ├── UserController.java
│       │       │   └── PostController.java
│       │       ├── service/
│       │       │   ├── UserService.java
│       │       │   ├── AuthService.java
│       │       │   └── PostService.java
│       │       ├── entity/
│       │       │   ├── User.java
│       │       │   ├── Post.java
│       │       │   └── Comment.java
│       │       ├── repository/
│       │       │   ├── UserRepository.java
│       │       │   ├── PostRepository.java
│       │       │   └── CommentRepository.java
│       │       ├── security/
│       │       │   ├── JwtTokenProvider.java
│       │       │   ├── JwtAuthenticationFilter.java
│       │       │   └── SecurityConfig.java
│       │       ├── dto/
│       │       │   ├── LoginRequest.java
│       │       │   ├── RegisterRequest.java
│       │       │   ├── JwtAuthenticationResponse.java
│       │       │   └── UserResponse.java
│       │       ├── exception/
│       │       │   ├── ResourceNotFoundException.java
│       │       │   ├── BadRequestException.java
│       │       │   └── GlobalExceptionHandler.java
│       │       └── utils/
│       │           ├── ValidationUtils.java
│       │           └── DateTimeUtils.java
│       └── resources/
│           ├── application.properties
│           ├── application-dev.properties
│           ├── application-prod.properties
│           └── db/
│               └── migration/
│                   └── V1__Initial_schema.sql
├── test/
│   └── java/com/d30/
│       ├── controller/
│       ├── service/
│       └── security/
├── pom.xml
├── Dockerfile
├── docker-compose.yml
├── .gitignore
├── README.md
└── SETUP_GUIDE.md (este arquivo)
```

---

## 🔧 SETUP INICIAL (Primeira Vez)

### **1. Clonar/Criar Projeto**

```powershell
# Criar estrutura de pastas
mkdir C:\Meus projetos\D30\d30-backend
cd C:\Meus projetos\D30\d30-backend

# Criar pastas principais
mkdir src\main\java\com\d30
mkdir src\main\resources
mkdir test\java\com\d30
```

### **2. Copiar Arquivos Fornecidos**

Copie esses arquivos para a raiz do `d30-backend/`:
- `pom.xml`
- `Dockerfile`
- `docker-compose.yml`
- `application.properties`

Copie esses Java files para `src/main/java/com/d30/`:
- `D30Application.java`
- `User.java` → `entity/`
- `JwtTokenProvider.java` → `security/`

### **3. Iniciar Database com Docker**

```powershell
cd C:\Meus projetos\D30\d30-backend

# Criar rede Docker
docker network create d30_network

# Iniciar PostgreSQL + pgAdmin + Redis
docker-compose up -d

# Verificar status
docker-compose ps

# Você deve ver:
# d30_postgres   - UP
# d30_pgadmin    - UP
# d30_redis      - UP
```

### **4. Acessar pgAdmin (Interface Gráfica)**

```
URL: http://localhost:5050
Email: admin@d30.com
Password: admin123

1. Adicionar novo server
2. Name: d30_postgres
3. Host: d30_postgres
4. Username: d30_user
5. Password: d30_secure_password_123
```

### **5. Build do Projeto**

```powershell
cd C:\Meus projetos\D30\d30-backend

# Baixar dependências e compilar
mvn clean install

# Isso vai levar ~2-3 min na primeira vez
```

### **6. Rodar Aplicação**

```powershell
mvn spring-boot:run

# Você deve ver:
# :::::::::::::: D30 BACKEND INICIADO ::::::::::::::
# Tomcat started on port(s): 8080
# Application 'd30-backend' is running
```

---

## ✅ VERIFICAR SE TÁ FUNCIONANDO

### **1. Health Check da API**

```bash
curl http://localhost:8080/api/actuator/health
# Resposta: {"status":"UP"}
```

### **2. Swagger API Documentation**

```
http://localhost:8080/api/swagger-ui.html
```

### **3. Database Connection**

```bash
# Conectar no banco diretamente
psql -h localhost -U d30_user -d d30_db

# Dentro do psql:
\dt  # listar tabelas
\l   # listar databases
```

---

## 🚀 WORKFLOW DE DESENVOLVIMENTO

### **Terminal 1 - Backend (Java)**

```powershell
cd C:\Meus projetos\D30\d30-backend
mvn spring-boot:run
```

Backend roda em: **http://localhost:8080/api**

### **Terminal 2 - Database**

```powershell
cd C:\Meus projetos\D30\d30-backend
docker-compose up
```

Banco de dados roda em: **localhost:5432**

pgAdmin em: **http://localhost:5050**

### **Terminal 3 - Frontend (React)**

```powershell
cd "C:\Meus projetos\D30\D30 Design System"
npm start
```

Frontend roda em: **http://localhost:3000**

---

## 📁 ARQUIVOS PRINCIPAIS EXPLICADOS

### **pom.xml**
- Arquivo Maven com todas as dependências
- Spring Boot, Spring Security, JWT, PostgreSQL, etc
- Você NÃO precisa mexer nele normalmente

### **application.properties**
- Configurações da aplicação
- Database connection string
- JWT secret key (⚠️ MUDAR EM PRODUÇÃO!)
- CORS settings

### **docker-compose.yml**
- Define PostgreSQL, pgAdmin, Redis
- `docker-compose up` inicia tudo
- `docker-compose down` desliga tudo

### **Dockerfile**
- Multi-stage build do Spring Boot
- Cria imagem Docker da aplicação
- Usado para deploy em produção

### **D30Application.java**
- Classe principal (@SpringBootApplication)
- Configura Password Encoder, CORS, etc
- Entry point da aplicação

### **User.java (Entity)**
- Modelo de usuário no banco
- @Entity = vai vira uma tabela
- @Column, @Email, @NotBlank = validações

### **JwtTokenProvider.java (Security)**
- Gera JWT tokens de forma segura
- Valida tokens nas requisições
- Extrai informações do token

---

## 🔐 VARIÁVEIS DE AMBIENTE

### **Criar .env.local** (Desenvolvimento)

```
DATABASE_URL=jdbc:postgresql://localhost:5432/d30_db
DATABASE_USER=d30_user
DATABASE_PASSWORD=d30_secure_password_123
JWT_SECRET=sua-chave-super-secreta-mude-isso-em-producao
JWT_EXPIRATION=86400000
SPRING_PROFILES_ACTIVE=dev
```

### **Usar em application.properties**

```properties
spring.datasource.url=${DATABASE_URL}
spring.datasource.username=${DATABASE_USER}
spring.datasource.password=${DATABASE_PASSWORD}
app.security.jwt.secret=${JWT_SECRET}
```

---

## 🧪 TESTAR ENDPOINTS

### **1. Register (Criar Usuário)**

```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "password": "Password123!",
    "fullName": "João Silva"
  }'

# Resposta esperada:
# {
#   "token": "eyJhbGciOiJIUzUxMiJ9...",
#   "user": {
#     "id": 1,
#     "email": "user@example.com",
#     "fullName": "João Silva"
#   }
# }
```

### **2. Login**

```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "password": "Password123!"
  }'

# Salve o token retornado
```

### **3. Acessar Endpoint Protegido**

```bash
curl -X GET http://localhost:8080/api/users/me \
  -H "Authorization: Bearer TOKEN_AQUI"
```

---

## 📊 TAREFAS PARA OS AGENTES

Passe esse checklist pros seus 5 agentes:

### **Developer:**
- [ ] Implementar UserController (CRUD)
- [ ] Implementar AuthController (login/register)
- [ ] Implementar PostController (posts do fórum)
- [ ] Implementar SecurityConfig
- [ ] Criar DTOs (Data Transfer Objects)
- [ ] Criar Exceptions handlers

### **Strategic Planner:**
- [ ] Definir API versioning strategy
- [ ] Documentar rate limiting rules
- [ ] Planejar caching strategy (Redis)
- [ ] Roadmap de features

### **Motion Frontend Expert:**
- [ ] Integrar React com API
- [ ] Criar interceptadores axios
- [ ] Gerenciar JWT no localStorage/cookies
- [ ] Animar erros/sucesso de requisições

### **Organization Manager:**
- [ ] Criar migrations de banco de dados
- [ ] Documentar API endpoints
- [ ] Criar test suites
- [ ] Setup CI/CD (GitHub Actions)

### **Marketing Strategist:**
- [ ] Comunicar arquitetura aos contribuidores
- [ ] Documentar como usar a API
- [ ] Criar exemplos de requisições
- [ ] Manter docs atualizada

---

## 🐛 TROUBLESHOOTING

### **Porta 5432 em uso**
```powershell
# Encontrar processo
netstat -ano | findstr :5432

# Matar processo (PID)
taskkill /PID 1234 /F
```

### **Docker não inicia**
```powershell
docker-compose down -v  # Remove volumes
docker-compose up       # Reinicia
```

### **Maven build falha**
```powershell
mvn clean  # Limpar cache
mvn install -DskipTests
```

### **JWT secret muito curto**
```properties
# Mínimo 32 caracteres!
app.security.jwt.secret=sua-chave-super-secreta-com-32-caracteres-ou-mais-aqui
```

---

## 📚 LINKS ÚTEIS

- Spring Boot Docs: https://spring.io/projects/spring-boot
- Spring Security: https://spring.io/projects/spring-security
- JWT: https://jwt.io/
- PostgreSQL: https://www.postgresql.org/
- Docker: https://www.docker.com/

---

**Pronto! Seu backend D30 tá 100% configurado e pronto pra trabalhar! 🚀**
