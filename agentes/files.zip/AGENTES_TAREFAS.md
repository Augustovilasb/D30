# 🤖 D30 BACKEND - TAREFAS PARA OS 5 AGENTES

**Data:** 19 de maio de 2026
**Projeto:** d30-backend (Spring Boot + PostgreSQL)
**Status:** Fase 1 - Setup & Foundation

---

## 📋 COMO USAR COM OS AGENTES

```powershell
python d30_multi_agent_system.py

Opção: 3 (Múltiplos agentes)
Selecione: Todos (1, 2, 3, 4, 5)
Cole a tarefa abaixo (por agente)
```

---

## 🎯 TAREFAS POR AGENTE

### **1️⃣ DEVELOPER (💻 Full-Stack Motion Developer)**

**TAREFA PRINCIPAL:**

Você é responsável pela **implementação do backend em Spring Boot**. 

Implemente os seguintes arquivos Java em `src/main/java/com/d30/`:

1. **security/SecurityConfig.java** — Configurar Spring Security com JWT
   - Desabilitar CSRF (API stateless)
   - Adicionar JwtAuthenticationFilter
   - Definir públicas/privadas endpoints
   
2. **security/JwtAuthenticationFilter.java** — Filtro JWT
   - Extrair token do header Authorization
   - Validar token com JwtTokenProvider
   - Adicionar usuário no SecurityContext

3. **controller/AuthController.java** — Endpoints de autenticação
   - POST /auth/register (criar usuário)
   - POST /auth/login (fazer login)
   - POST /auth/logout (logout)
   - POST /auth/refresh (renovar token)

4. **controller/UserController.java** — Endpoints de usuário
   - GET /users/me (dados do usuário logado)
   - PUT /users/me (atualizar perfil)
   - GET /users/{id} (ver perfil de outro)
   - DELETE /users/me (deletar conta)

5. **dto/** — Data Transfer Objects
   - LoginRequest.java
   - RegisterRequest.java
   - JwtAuthenticationResponse.java
   - UserResponse.java
   - UpdateUserRequest.java

6. **service/AuthService.java** — Lógica de autenticação
   - Validar email/password
   - Usar PasswordEncoder do Spring Security
   - Retornar JWT token

7. **service/UserService.java** — Lógica de usuário
   - CRUD operations
   - Encriptação de senhas
   - Validações

8. **repository/UserRepository.java** — Interface JPA
   - findByEmail(String email)
   - existsByEmail(String email)

9. **exception/GlobalExceptionHandler.java** — Tratamento de erros
   - @ExceptionHandler para cada exceção
   - Retornar JSON com erro
   - Log de erros

10. **Testes (test/java/)**
    - UserControllerTest.java
    - AuthServiceTest.java
    - JwtTokenProviderTest.java

**ARQUIVOS JÁ FORNECIDOS:**
- ✅ pom.xml (dependências)
- ✅ application.properties (config)
- ✅ D30Application.java (main class)
- ✅ User.java (entity)
- ✅ JwtTokenProvider.java (JWT)

**PRIORIDADE:** 🔴 CRÍTICA
**DEADLINE:** Fim da semana 1
**ESTIMATIVA:** 30-40 horas

---

### **2️⃣ ORGANIZATION MANAGER (📋 Organization Manager)**

**TAREFA PRINCIPAL:**

Você é responsável pela **estrutura, documentação e processos**.

1. **Database Schema** — Criar migrations SQL
   - `db/migration/V1__Initial_schema.sql` — Criar tabelas (users, posts, comments)
   - Índices, constraints, foreign keys
   - Usar Flyway/Liquibase para versionamento

2. **README.md** — Documentação do projeto
   - Como clonar
   - Como buildar
   - Como rodar localmente
   - Stack tecnológico
   - Contribução

3. **.gitignore** — Arquivos a ignorar
   - target/
   - .DS_Store
   - .env.local
   - *.log
   - node_modules/

4. **application-dev.properties** — Configuração para desenvolvimento
   - Database local
   - Logging DEBUG
   - CORS aberto
   - JWT secret genérico

5. **application-prod.properties** — Configuração para produção
   - Database na nuvem
   - Logging INFO
   - CORS restritivo
   - JWT secret forte

6. **API Documentation** — Documentar endpoints
   - `/docs/API.md` — Todos os endpoints
   - Exemplos de requisições/respostas
   - Autenticação
   - Rate limiting

7. **CONTRIBUTING.md** — Como contribuir
   - Branch strategy
   - Commit message format
   - PR checklist
   - Code style

8. **Logging Strategy**
   - `src/main/resources/logback-spring.xml`
   - Logs em arquivo
   - Níveis por package
   - Sem dados sensíveis nos logs

9. **Test Strategy**
   - Estrutura de testes
   - Unit tests
   - Integration tests
   - Coverage targets (80%+)

10. **GitHub Actions Setup** — CI/CD
    - `.github/workflows/build.yml`
    - `.github/workflows/test.yml`
    - `.github/workflows/deploy.yml`

**PRIORIDADE:** 🟡 MÉDIA-ALTA
**DEADLINE:** Fim da semana 1
**ESTIMATIVA:** 20-25 horas

---

### **3️⃣ STRATEGIC PLANNER (🎯 Strategic Planner)**

**TAREFA PRINCIPAL:**

Você é responsável pela **estratégia técnica e roadmap**.

1. **API Versioning Strategy**
   - Definir como versionará endpoints
   - `/api/v1/users`, `/api/v2/users`
   - Deprecation policy

2. **Rate Limiting Rules**
   - Limite global: 100 req/min por IP
   - Login: 5 tentativas/15min
   - Password reset: 3 tentativas/1hora
   - Implementar com Spring Security/Bucket4j

3. **Caching Strategy**
   - Redis para:
     - User profiles
     - Posts populares
     - Forum threads
   - TTL policies

4. **Backend Roadmap** (6 meses)
   - **Phase 1 (Semana 1-2):** Auth + User CRUD
   - **Phase 2 (Semana 3-4):** Forum (Posts/Comments)
   - **Phase 3 (Semana 5-6):** Search + Notifications
   - **Phase 4:** Analytics + Admin panel

5. **Performance Targets**
   - Response time: <200ms (p95)
   - Database queries: <50ms
   - Uptime: 99.5%
   - Load capacity: 1000 users simultâneos

6. **Security Roadmap**
   - Week 1: Auth + HTTPS
   - Week 2: Input validation + XSS protection
   - Week 3: CSRF + CORS
   - Week 4: Rate limiting + Monitoring

7. **Monitoring & Alerts**
   - Defini métricas importantes
   - Alertas de erro
   - Dashboard de performance

8. **Scalability Plan**
   - Quando passar de 1000 usuários?
   - Database sharding strategy
   - Load balancing
   - Microservices (futuro)

9. **Cost Estimation**
   - Database: $15/mês (Heroku)
   - API Gateway: $5/mês
   - Redis cache: $10/mês
   - CDN: $5/mês

10. **Compliance & Regulations**
    - LGPD (Lei Geral de Proteção de Dados)
    - GDPR (se tiver usuários EU)
    - Cookie policy
    - Terms of Service

**PRIORIDADE:** 🟡 MÉDIA
**DEADLINE:** Fim da semana 1
**ESTIMATIVA:** 15-20 horas

---

### **4️⃣ MOTION FRONTEND EXPERT (✨ Motion Front-End Expert)**

**TAREFA PRINCIPAL:**

Você é responsável pela **integração Frontend + Backend**.

1. **API Client Setup** — Axios/Fetch
   - `src/api/client.js` — Configurar baseURL
   - Interceptadores para JWT
   - Error handling

2. **JWT Management**
   - Salvar token em httpOnly cookie OU localStorage
   - Recuperar token em requisições
   - Renovar token antes de expirar
   - Logout e limpar token

3. **Auth Integration**
   - Conectar FormLogin com `/api/auth/login`
   - Conectar FormRegister com `/api/auth/register`
   - Redirecionar pós-login
   - Proteger rotas privadas

4. **User Profile**
   - GET `/api/users/me` ao carregar app
   - Salvar em context/zustand
   - Mostrar dados do usuário na UI

5. **Forum Integration**
   - Conectar GET `/api/posts` → mostrar posts
   - Conectar POST `/api/posts` → criar post
   - Conectar POST `/api/comments` → comentar
   - Real-time updates (websockets futura)

6. **Error Handling**
   - Mostrar erros em toasts
   - 401 → redirecionar login
   - 403 → não tem permissão
   - 500 → erro servidor

7. **Loading States**
   - Spinner enquanto carrega
   - Disable botão enquanto submete
   - Skeleton loaders

8. **Form Validation**
   - Validar antes de enviar
   - Mostrar erros do backend
   - Re-tentar em caso de erro

9. **Motion Design** — Animar integrações
   - Transição ao fazer login
   - Animação ao postar no fórum
   - Feedback visual de sucesso/erro

10. **React Hooks Customizados**
    - useAuth() — autenticação
    - useApi() — chamadas de API
    - useUser() — dados do usuário

**PRIORIDADE:** 🟡 MÉDIA
**DEADLINE:** Fim da semana 2
**ESTIMATIVA:** 20-25 horas

---

### **5️⃣ MARKETING STRATEGIST (📢 Marketing Strategist)**

**TAREFA PRINCIPAL:**

Você é responsável pela **comunicação técnica** e **atração de contribuidores**.

1. **Architecture Documentation**
   - Criar `/docs/ARCHITECTURE.md`
   - Diagrama da stack
   - Fluxo de autenticação
   - Fluxo de dados

2. **Contributing Guide Enhancement**
   - Como setup local
   - Como rodar testes
   - Commit message format
   - PR template

3. **API Examples**
   - Documentar todos os endpoints
   - Exemplos cURL
   - Exemplos JavaScript (Axios)
   - Postman collection

4. **Developer Onboarding**
   - Guide para novo desenvolvedor
   - Troubleshooting comum
   - Links úteis
   - Contatos

5. **Blog Posts/Tutorials** (Futuro)
   - "Como contribuir ao D30"
   - "Spring Boot + React"
   - "JWT Security"

6. **Community Engagement**
   - Responder dúvidas em Issues
   - Review de PRs
   - Feedback construtivo

7. **Feature Announcements**
   - Comunicar novo backend
   - Listar features
   - Como usar

8. **Changelog Maintenance**
   - Manter CHANGELOG.md
   - Documentar cada versão
   - Breaking changes destacados

9. **Badges & Status**
   - Build status badge
   - Coverage badge
   - Version badge
   - License

10. **Video Tutorials** (Opcional)
    - Como fazer setup
    - Como fazer primeiro POST
    - Como fazer login

**PRIORIDADE:** 🟢 BAIXA-MÉDIA
**DEADLINE:** Fim da semana 2
**ESTIMATIVA:** 10-15 horas

---

## 📊 CRONOGRAMA

```
SEMANA 1:
├── Developer: Auth + User CRUD (Critical)
├── Organization Manager: Database + Setup (Critical)
└── Strategic Planner: Planning + Strategy (Medium)

SEMANA 2:
├── Motion Frontend: API Integration (Medium)
├── Marketing: Documentation (Low)
└── Developer: Forum endpoints (Medium)

SEMANA 3-4:
├── Todos: Bug fixes + Refinements
├── Testing & QA
└── Deployment preparation
```

---

## 🎯 PRÓXIMOS PASSOS

1. **Ler SETUP_GUIDE.md** — Todos os agentes
2. **Setup local** — Testar banco de dados
3. **Criar branches** — Por feature/agente
4. **PR reviews** — Code quality
5. **Deploy staging** — Testar antes de prod

---

## 📞 CONTATO & SUPORTE

- **Issues:** https://github.com/Augustovilasb/D30/issues
- **Discussions:** https://github.com/Augustovilasb/D30/discussions
- **Email:** augustovilasb@hotmail.com

---

**Bora codar! 🚀**
